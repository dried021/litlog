package com.bookfox.LitLog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LitLogApplication {

	public static void main(String[] args) {
		SpringApplication.run(LitLogApplication.class, args);
	}

}
